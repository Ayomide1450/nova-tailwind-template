# Nova – Tailwind CSS Landing Page Template

**Nova** is a modern, responsive, and beautifully animated landing page template built using **Tailwind CSS**. Designed for creators, freelancers, and startups, Nova helps you launch websites fast without coding from scratch.

---

## ✨ Features
- ⚡ **Built with Tailwind CSS v2** – clean, modern, and scalable
- 🎨 **Stunning gradient design** with glassmorphism cards
- 📱 **Fully responsive** – looks great on mobile, tablet, and desktop
- 🌀 **Smooth scroll + scroll reveal animations** (AOS integrated)
- 💼 Sections included:
  - Hero  
  - About  
  - Services  
  - Testimonials  
  - Contact  
  - Footer
- 🧩 Easy to customize and extend

---

## 🧰 Folder Structure
