AOS.init({
  duration: 1000,
  once: true,
});
